vim.opt.relativenumber = true
vim.api.nvim_set_option("clipboard", "unnamedplus")
