local M = {}
M.options, M.ui, M.mappings, M.plugins = {} , {}, {}, {}

M.ui = {
  theme = 'gruvchad',
  tabufline = { lazyload = false},
}

M.plugins = "custom.plugins"
M.mappings = require "custom.mappings"

return M
